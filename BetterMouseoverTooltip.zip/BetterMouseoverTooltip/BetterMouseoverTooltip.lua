local tooltipFrame = CreateFrame("Frame");
local scale = 1;

tooltipFrame:SetScript("OnUpdate", function(self, delta)
    if not GameTooltip:IsShown() or GameTooltip:GetAnchorType() ~= "ANCHOR_NONE" then return end;

    local xValue, yValue = GetCursorPosition();

    xValue = xValue / scale - 1;
    yValue = yValue / scale + 11;

    GameTooltip:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", xValue, yValue);
end);

GameTooltip:HookScript("OnShow", function()
    tooltipFrame:Show();
end);

GameTooltip:HookScript("OnHide", function()
    tooltipFrame:Hide();
end);

-- We set-unset owner to free the tooltip window
hooksecurefunc("GameTooltip_SetDefaultAnchor", function(tooltip, parent)
    tooltip:SetOwner(parent, "ANCHOR_CURSOR");
    tooltip:SetOwner(parent, "ANCHOR_NONE");

    scale = UIParent:GetEffectiveScale();
end);